# AI Border Defence & Surveillance System - Complete Documentation

## 📋 Table of Contents
1. [System Overview](#system-overview)
2. [Architecture](#architecture)
3. [Features](#features)
4. [Installation & Setup](#installation--setup)
5. [Component Guide](#component-guide)
6. [API Routes](#api-routes)
7. [Database Schema](#database-schema)
8. [Configuration](#configuration)
9. [Deployment](#deployment)
10. [Troubleshooting](#troubleshooting)

---

## System Overview

The **AI Border Defence & Surveillance System** is a comprehensive, military-grade monitoring platform designed for real-time border surveillance, threat detection, and anomaly analysis. Built with modern web technologies, it provides a glassmorphic user interface with neon green accents and advanced AI-powered threat detection capabilities.

### Key Technologies
- **Frontend:** React 19, TypeScript, Tailwind CSS 4, Recharts
- **Backend:** Express.js, tRPC, Node.js
- **Database:** MySQL/TiDB with Drizzle ORM
- **Authentication:** Manus OAuth
- **Maps:** Google Maps API
- **Real-time:** WebSocket support

---

## Architecture

### System Architecture Diagram
```
┌─────────────────────────────────────────────────────────────┐
│                    Client Layer (React)                      │
│  ┌──────────────┬──────────────┬──────────────┬────────────┐ │
│  │  Dashboard   │ Surveillance │  Detection   │  Heatmap   │ │
│  ├──────────────┼──────────────┼──────────────┼────────────┤ │
│  │  Border Map  │    Alerts    │   Reports    │ Settings   │ │
│  └──────────────┴──────────────┴──────────────┴────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                    API Layer (tRPC)                          │
│  ┌──────────────┬──────────────┬──────────────┬────────────┐ │
│  │    Auth      │ Border Zones │ Surveillance │  Threats   │ │
│  ├──────────────┼──────────────┼──────────────┼────────────┤ │
│  │    Alerts    │   Reports    │   Dashboard  │  System    │ │
│  └──────────────┴──────────────┴──────────────┴────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                  Database Layer (MySQL)                      │
│  ┌──────────────┬──────────────┬──────────────┬────────────┐ │
│  │    Users     │ Border Zones │ Surveillance │  Threats   │ │
│  ├──────────────┼──────────────┼──────────────┼────────────┤ │
│  │    Alerts    │   Reports    │  Detection   │   Logs     │ │
│  └──────────────┴──────────────┴──────────────┴────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## Features

### 🔐 Authentication & Security
- **OAuth Integration:** Secure Manus OAuth authentication
- **Session Management:** Automatic session handling with JWT
- **Role-Based Access Control:** Admin and Officer roles
- **Logout System:** Secure session cleanup

### 📊 Dashboard
- **Live Statistics:** Real-time threat and detection counts
- **Animated Radar:** Visual threat monitoring with radar sweep animation
- **Drone Monitoring:** Drone status and tracking
- **System Status:** Database, AI modules, and system health
- **Live Clock:** Real-time system time, date, and day display

### 📹 Surveillance Monitoring
- **Multi-Zone Monitoring:** Monitor multiple border zones simultaneously
- **Camera Feed Simulation:** Realistic camera feed interface
- **Zone Status:** Real-time zone activity status
- **Drone Control:** Drone simulation and control interface
- **Live Updates:** Real-time surveillance data streaming

### 🤖 AI Detection Engine
- **Object Detection:** YOLO-style person, vehicle, and drone detection
- **Anomaly Detection:** Unusual movement and behavior detection
- **Risk Zone Prediction:** Predictive threat analysis
- **Confidence Scoring:** Detection confidence percentages
- **GPU Monitoring:** Real-time GPU and memory usage tracking

### 🔥 Heatmap Visualization
- **Threat Density Mapping:** Visual representation of threat concentration
- **Zone Analysis:** Detailed threat analysis per zone
- **Activity Timeline:** Historical activity tracking
- **Risk Assessment:** Zone-by-zone risk scoring
- **Interactive Visualization:** Zoom and pan capabilities

### 🗺️ Border Map Integration
- **Google Maps Integration:** Real-time border visualization
- **Zone Markers:** Customizable zone markers and overlays
- **Threat Overlays:** Visual threat indicators on map
- **Patrol Routes:** Drone and patrol route visualization
- **Location Tracking:** Real-time location monitoring

### 🚨 Alert Management
- **Real-Time Alerts:** Instant threat notifications
- **Severity Levels:** Critical, Warning, and Info classifications
- **Alert Filtering:** Advanced filtering by severity and status
- **Alert History:** Complete alert audit trail
- **Sound Notifications:** Audio alert notifications
- **Email/SMS Alerts:** Multi-channel notification system

### 📈 Reports & Analytics
- **Activity Charts:** Line, bar, and pie charts
- **Detection Statistics:** Detailed detection breakdowns
- **Zone Risk Analysis:** Risk assessment per zone
- **Export Functionality:** PDF, CSV, and JSON export
- **Historical Analysis:** Trend analysis and predictions
- **Custom Reports:** Customizable report generation

### ⚙️ Settings & Configuration
- **System Configuration:** System name, timezone, language
- **Notification Preferences:** Email and SMS settings
- **Border Zone Management:** Add/edit/delete zones
- **User Management:** User creation and role assignment
- **Security Settings:** Password policies and 2FA
- **Backup Configuration:** Automatic backup scheduling

---

## Installation & Setup

### Prerequisites
- Node.js 22.13.0 or higher
- npm or pnpm package manager
- MySQL 8.0 or TiDB
- Google Maps API key (optional)

### Step 1: Clone & Install Dependencies
```bash
cd /home/ubuntu/ai-border-surveillance-system
pnpm install
```

### Step 2: Environment Configuration
Create a `.env.local` file in the project root:
```env
DATABASE_URL=mysql://user:password@localhost:3306/border_surveillance
JWT_SECRET=your-secret-key-here
VITE_APP_ID=your-manus-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
GOOGLE_MAPS_API_KEY=your-google-maps-key
```

### Step 3: Database Setup
```bash
# Generate migrations
pnpm drizzle-kit generate

# Apply migrations
pnpm drizzle-kit migrate
```

### Step 4: Start Development Server
```bash
pnpm dev
```

The application will be available at `http://localhost:3000`

### Step 5: Build for Production
```bash
pnpm build
pnpm start
```

---

## Component Guide

### Core Components

#### 1. **LiveClock Component**
Real-time system clock with date and day display.

```typescript
import { LiveClock } from '@/components/LiveClock';

<LiveClock 
  format="24h"      // or "12h"
  showDate={true}   // Show date
  showDay={true}    // Show day of week
  className=""      // Custom CSS classes
/>
```

#### 2. **SidebarNav Component**
Responsive sidebar navigation with live clock integration.

```typescript
import { SidebarNav } from '@/components/SidebarNav';

<SidebarNav 
  onLogout={handleLogout}
  userName="Operator Name"
/>
```

#### 3. **GlassCard Component**
Reusable glassmorphic card component.

```typescript
import { GlassCard } from '@/components/GlassCard';

<GlassCard className="p-6">
  {/* Content */}
</GlassCard>
```

#### 4. **StatCard Component**
Statistics display card with trend indicators.

```typescript
import { StatCard } from '@/components/GlassCard';

<StatCard
  label="Total Alerts"
  value="42"
  unit="today"
  icon="🚨"
  trend="up"  // or "down", "stable"
/>
```

#### 5. **AlertCard Component**
Alert notification card with severity styling.

```typescript
import { AlertCard } from '@/components/GlassCard';

<AlertCard
  title="Perimeter Breach"
  message="Unauthorized entry detected"
  severity="critical"  // or "warning", "info"
  timestamp={new Date()}
  onDismiss={() => {}}
/>
```

#### 6. **RadarAnimation Component**
Animated radar visualization.

```typescript
import { RadarAnimation } from '@/components/RadarAnimation';

<RadarAnimation />
```

#### 7. **LoadingAnimation Component**
Loading spinner with percentage display.

```typescript
import { LoadingAnimation } from '@/components/LoadingAnimation';

<LoadingAnimation percentage={65} />
```

---

## API Routes

### Authentication Routes
```typescript
// Get current user
trpc.auth.me.useQuery()

// Logout
trpc.auth.logout.useMutation()
```

### Border Zones Routes
```typescript
// Get all zones
trpc.borderZones.list.useQuery()

// Get zone details
trpc.borderZones.getById.useQuery({ id: 1 })

// Create zone
trpc.borderZones.create.useMutation()

// Update zone
trpc.borderZones.update.useMutation()

// Delete zone
trpc.borderZones.delete.useMutation()
```

### Surveillance Routes
```typescript
// Get surveillance feeds
trpc.surveillance.list.useQuery()

// Get feed by zone
trpc.surveillance.getByZone.useQuery({ zoneId: 1 })

// Update feed status
trpc.surveillance.updateStatus.useMutation()
```

### Threat Detection Routes
```typescript
// Get recent threats
trpc.threats.recent.useQuery({ limit: 10 })

// Get threats by zone
trpc.threats.byZone.useQuery({ zoneId: 1 })

// Get threats by severity
trpc.threats.bySeverity.useQuery({ severity: 'critical' })

// Create threat detection
trpc.threats.create.useMutation()
```

### Alerts Routes
```typescript
// Get recent alerts
trpc.alerts.recent.useQuery({ limit: 20 })

// Get alerts by zone
trpc.alerts.byZone.useQuery({ zoneId: 1 })

// Get alerts by severity
trpc.alerts.bySeverity.useQuery({ severity: 'critical' })

// Create alert
trpc.alerts.create.useMutation()

// Update alert status
trpc.alerts.updateStatus.useMutation()
```

### Reports Routes
```typescript
// Get recent reports
trpc.reports.recent.useQuery({ limit: 10 })

// Generate report
trpc.reports.generate.useMutation()

// Export report
trpc.reports.export.useMutation({ format: 'pdf' })
```

### Dashboard Routes
```typescript
// Get dashboard stats
trpc.dashboard.getStats.useQuery()

// Get threat trends
trpc.dashboard.getTrends.useQuery({ days: 7 })
```

---

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  openId VARCHAR(64) UNIQUE NOT NULL,
  name TEXT,
  email VARCHAR(320),
  loginMethod VARCHAR(64),
  role ENUM('user', 'admin') DEFAULT 'user',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  lastSignedIn TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Border Zones Table
```sql
CREATE TABLE border_zones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  country VARCHAR(255),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  radius INT,
  riskLevel INT DEFAULT 0,
  status VARCHAR(50) DEFAULT 'active',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Surveillance Feeds Table
```sql
CREATE TABLE surveillance_feeds (
  id INT AUTO_INCREMENT PRIMARY KEY,
  zoneId INT NOT NULL,
  cameraName VARCHAR(255),
  feedUrl VARCHAR(500),
  status VARCHAR(50) DEFAULT 'active',
  lastUpdate TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (zoneId) REFERENCES border_zones(id)
);
```

### Threat Detections Table
```sql
CREATE TABLE threat_detections (
  id INT AUTO_INCREMENT PRIMARY KEY,
  zoneId INT NOT NULL,
  detectionType VARCHAR(100),
  confidence DECIMAL(5, 2),
  severity VARCHAR(50),
  details JSON,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (zoneId) REFERENCES border_zones(id)
);
```

### Alerts Table
```sql
CREATE TABLE alerts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  severity VARCHAR(50),
  status VARCHAR(50) DEFAULT 'active',
  zoneId INT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (zoneId) REFERENCES border_zones(id)
);
```

### Reports Table
```sql
CREATE TABLE reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content JSON,
  generatedBy INT,
  generatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (generatedBy) REFERENCES users(id)
);
```

---

## Configuration

### Tailwind CSS Theme
The system uses a custom military theme with neon green accents. Key colors:

```css
--primary: #22c55e (Neon Green)
--background: #0a0e27 (Military Dark)
--card: #0f172a (Dark Card)
--destructive: #ef4444 (Red)
--chart-1: #22c55e (Green)
--chart-2: #0ea5e9 (Blue)
--chart-3: #06b6d4 (Cyan)
--chart-4: #8b5cf6 (Purple)
--chart-5: #ec4899 (Pink)
```

### Animation Classes
- `.animate-radar-pulse` - Radar pulse effect
- `.animate-radar-sweep` - Radar sweep rotation
- `.animate-glow-pulse` - Neon glow pulsing
- `.animate-neon-flicker` - Neon flicker effect
- `.animate-slide-in-left` - Slide in from left
- `.animate-slide-in-right` - Slide in from right
- `.animate-fade-in` - Fade in effect
- `.animate-loading-spin` - Loading spinner
- `.animate-bounce-pulse` - Bounce pulse effect

---

## Deployment

### Deploy to Manus Platform
1. Create a checkpoint in the Management UI
2. Click the **Publish** button
3. Configure custom domain (optional)
4. Enable SSL/TLS
5. Monitor deployment status

### Deploy to External Hosting
```bash
# Build production bundle
pnpm build

# Deploy dist folder to your hosting provider
# Example: Vercel, Netlify, Railway, etc.
```

### Environment Variables for Production
```env
NODE_ENV=production
DATABASE_URL=mysql://user:password@host:3306/db
JWT_SECRET=strong-secret-key
VITE_APP_ID=production-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
GOOGLE_MAPS_API_KEY=your-production-key
```

---

## Troubleshooting

### Common Issues

#### 1. **Build Errors with Tailwind CSS**
**Problem:** `Cannot apply unknown utility class`

**Solution:**
```bash
# Clear cache and rebuild
rm -rf node_modules/.vite
pnpm build
```

#### 2. **Database Connection Failed**
**Problem:** `Error: connect ECONNREFUSED`

**Solution:**
- Verify MySQL is running
- Check DATABASE_URL in .env
- Ensure database exists
- Check user permissions

#### 3. **OAuth Login Not Working**
**Problem:** Redirect URI mismatch

**Solution:**
- Verify VITE_APP_ID in .env
- Check OAuth callback URL in Manus dashboard
- Ensure OAUTH_SERVER_URL is correct

#### 4. **Maps Not Loading**
**Problem:** Google Maps API errors

**Solution:**
- Verify GOOGLE_MAPS_API_KEY is valid
- Enable Maps JavaScript API in Google Cloud Console
- Check API key restrictions

#### 5. **Real-time Updates Not Working**
**Problem:** WebSocket connection fails

**Solution:**
- Check firewall rules
- Verify WebSocket port is open
- Check server logs for connection errors

---

## Performance Optimization

### Frontend Optimization
- Code splitting with dynamic imports
- Image lazy loading
- CSS minification
- JavaScript minification
- Gzip compression

### Backend Optimization
- Database query optimization
- Connection pooling
- Caching strategies
- Rate limiting
- Load balancing

### Monitoring & Logging
- Application performance monitoring (APM)
- Error tracking and reporting
- Request/response logging
- Database query logging
- Real-time alerts for errors

---

## Security Best Practices

1. **Authentication:** Always use OAuth for login
2. **Authorization:** Implement role-based access control
3. **Data Protection:** Use HTTPS/TLS for all connections
4. **Database:** Use parameterized queries to prevent SQL injection
5. **Environment Variables:** Never commit secrets to version control
6. **Rate Limiting:** Implement rate limiting on API endpoints
7. **CORS:** Configure CORS properly for security
8. **Input Validation:** Validate all user inputs
9. **Session Management:** Use secure session cookies
10. **Monitoring:** Log and monitor all security events

---

## Support & Documentation

For additional help:
- Check the project README.md
- Review component source code comments
- Check API route implementations
- Review database schema documentation
- Check deployment guides

---

**System Version:** 1.0.0  
**Last Updated:** April 10, 2026  
**Maintained By:** Border Defence System Team
