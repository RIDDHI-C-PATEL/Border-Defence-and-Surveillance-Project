import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getAllBorderZones,
  getBorderZoneById,
  getSurveillanceFeedsByZone,
  getRecentThreatDetections,
  getThreatDetectionsByZone,
  getRecentAlerts,
  getAlertsByZone,
  getAlertsBySeverity,
  getRecentReports,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Border Zones API
  borderZones: router({
    list: publicProcedure.query(async () => {
      return getAllBorderZones();
    }),
    getById: publicProcedure.input(z.number()).query(async ({ input }) => {
      return getBorderZoneById(input);
    }),
  }),

  // Surveillance Feeds API
  surveillance: router({
    feedsByZone: publicProcedure.input(z.number()).query(async ({ input }) => {
      return getSurveillanceFeedsByZone(input);
    }),
  }),

  // Threat Detection API
  threats: router({
    recent: publicProcedure.input(z.number().optional()).query(async ({ input }) => {
      return getRecentThreatDetections(input || 10);
    }),
    byZone: publicProcedure.input(z.number()).query(async ({ input }) => {
      return getThreatDetectionsByZone(input);
    }),
  }),

  // Alerts API
  alerts: router({
    recent: publicProcedure.input(z.number().optional()).query(async ({ input }) => {
      return getRecentAlerts(input || 20);
    }),
    byZone: publicProcedure.input(z.number()).query(async ({ input }) => {
      return getAlertsByZone(input);
    }),
    bySeverity: publicProcedure.input(z.enum(["info", "warning", "critical"])).query(async ({ input }) => {
      return getAlertsBySeverity(input);
    }),
  }),

  // Reports API
  reports: router({
    recent: publicProcedure.input(z.number().optional()).query(async ({ input }) => {
      return getRecentReports(input || 10);
    }),
  }),

  // Dashboard Stats API
  dashboard: router({
    stats: publicProcedure.query(async () => {
      const zones = await getAllBorderZones();
      const recentAlerts = await getRecentAlerts(5);
      const recentThreats = await getRecentThreatDetections(5);
      
      return {
        totalZones: zones.length,
        activeZones: zones.filter(z => z.status === 'active').length,
        criticalAlerts: recentAlerts.filter(a => a.severity === 'critical').length,
        recentThreats: recentThreats.length,
        timestamp: new Date(),
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
