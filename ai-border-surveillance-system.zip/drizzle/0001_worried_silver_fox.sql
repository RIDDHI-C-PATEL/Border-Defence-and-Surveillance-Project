CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`borderZoneId` int NOT NULL,
	`threatDetectionId` int,
	`title` varchar(255) NOT NULL,
	`description` text,
	`severity` enum('info','warning','critical') DEFAULT 'info',
	`status` enum('active','acknowledged','resolved') DEFAULT 'active',
	`assignedTo` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `borderZones` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`country` varchar(255) NOT NULL,
	`latitude` decimal(10,6) NOT NULL,
	`longitude` decimal(10,6) NOT NULL,
	`riskLevel` enum('low','medium','high','critical') DEFAULT 'low',
	`status` enum('active','inactive','monitoring') DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `borderZones_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`borderZoneId` int,
	`reportType` varchar(100) NOT NULL,
	`title` varchar(255) NOT NULL,
	`summary` text,
	`data` json,
	`generatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `surveillanceFeeds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`borderZoneId` int NOT NULL,
	`feedName` varchar(255) NOT NULL,
	`feedUrl` text,
	`cameraType` varchar(100),
	`status` enum('online','offline','error') DEFAULT 'online',
	`lastActive` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `surveillanceFeeds_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `threatDetections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`borderZoneId` int NOT NULL,
	`detectionType` varchar(100) NOT NULL,
	`confidence` decimal(5,2) NOT NULL,
	`latitude` decimal(10,6),
	`longitude` decimal(10,6),
	`description` text,
	`status` enum('detected','verified','false_alarm','resolved') DEFAULT 'detected',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `threatDetections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','operator') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `notificationEmail` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `users` ADD `notificationSms` boolean DEFAULT false;