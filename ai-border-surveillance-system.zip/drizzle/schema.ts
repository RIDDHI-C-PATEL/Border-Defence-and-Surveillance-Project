import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "operator"]).default("user").notNull(),
  notificationEmail: boolean("notificationEmail").default(true),
  notificationSms: boolean("notificationSms").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Border Zones Table
export const borderZones = mysqlTable("borderZones", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  country: varchar("country", { length: 255 }).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 6 }).notNull(),
  longitude: decimal("longitude", { precision: 10, scale: 6 }).notNull(),
  riskLevel: mysqlEnum("riskLevel", ["low", "medium", "high", "critical"]).default("low"),
  status: mysqlEnum("status", ["active", "inactive", "monitoring"]).default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BorderZone = typeof borderZones.$inferSelect;
export type InsertBorderZone = typeof borderZones.$inferInsert;

// Surveillance Feeds Table
export const surveillanceFeeds = mysqlTable("surveillanceFeeds", {
  id: int("id").autoincrement().primaryKey(),
  borderZoneId: int("borderZoneId").notNull(),
  feedName: varchar("feedName", { length: 255 }).notNull(),
  feedUrl: text("feedUrl"),
  cameraType: varchar("cameraType", { length: 100 }),
  status: mysqlEnum("status", ["online", "offline", "error"]).default("online"),
  lastActive: timestamp("lastActive"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SurveillanceFeed = typeof surveillanceFeeds.$inferSelect;
export type InsertSurveillanceFeed = typeof surveillanceFeeds.$inferInsert;

// Threat Detections Table
export const threatDetections = mysqlTable("threatDetections", {
  id: int("id").autoincrement().primaryKey(),
  borderZoneId: int("borderZoneId").notNull(),
  detectionType: varchar("detectionType", { length: 100 }).notNull(),
  confidence: decimal("confidence", { precision: 5, scale: 2 }).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 6 }),
  longitude: decimal("longitude", { precision: 10, scale: 6 }),
  description: text("description"),
  status: mysqlEnum("status", ["detected", "verified", "false_alarm", "resolved"]).default("detected"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ThreatDetection = typeof threatDetections.$inferSelect;
export type InsertThreatDetection = typeof threatDetections.$inferInsert;

// Alerts Table
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  borderZoneId: int("borderZoneId").notNull(),
  threatDetectionId: int("threatDetectionId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  severity: mysqlEnum("severity", ["info", "warning", "critical"]).default("info"),
  status: mysqlEnum("status", ["active", "acknowledged", "resolved"]).default("active"),
  assignedTo: int("assignedTo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;

// Reports Table
export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  borderZoneId: int("borderZoneId"),
  reportType: varchar("reportType", { length: 100 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  summary: text("summary"),
  data: json("data"),
  generatedBy: int("generatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;