import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, StatCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Detection() {
  const { user, logout } = useAuth();
  const [selectedModel, setSelectedModel] = useState('yolo-v8');

  const detections = [
    { id: 1, type: 'Person', confidence: 0.98, x: 120, y: 80, size: 60 },
    { id: 2, type: 'Vehicle', confidence: 0.95, x: 250, y: 150, size: 100 },
    { id: 3, type: 'Drone', confidence: 0.87, x: 400, y: 50, size: 40 },
  ];

  const anomalies = [
    { id: 1, type: 'Unusual Movement', confidence: 0.92, zone: 'Alpha', severity: 'critical' },
    { id: 2, type: 'Crowd Gathering', confidence: 0.85, zone: 'Beta', severity: 'warning' },
    { id: 3, type: 'Perimeter Breach', confidence: 0.78, zone: 'Gamma', severity: 'critical' },
  ];

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">AI DETECTION ENGINE</h1>
            <p className="text-gray-400">Real-time object detection, anomaly analysis & threat prediction</p>
          </div>

          {/* Model Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-slide-in-left">
            <StatCard
              label="Active Model"
              value={selectedModel.toUpperCase()}
              icon="🤖"
              trend="stable"
            />
            <StatCard
              label="Detection Accuracy"
              value="94.7"
              unit="%"
              icon="🎯"
              trend="up"
            />
            <StatCard
              label="Processing Speed"
              value="45"
              unit="fps"
              icon="⚡"
              trend="stable"
            />
          </div>

          {/* Main Detection View */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
            {/* Video Feed with Detections */}
            <div className="lg:col-span-2">
              <GlassCard className="p-0 overflow-hidden">
                <div className="relative bg-black aspect-video flex items-center justify-center">
                  {/* Simulated Video with Detection Boxes */}
                  <div className="absolute inset-0 bg-gradient-to-br from-green-900/20 to-black/50" />
                  
                  {/* Detection Boxes */}
                  {detections.map((detection) => (
                    <div
                      key={detection.id}
                      className="absolute border-2 border-neon-green bg-neon-green/5 flex items-end justify-start p-1"
                      style={{
                        left: `${detection.x}px`,
                        top: `${detection.y}px`,
                        width: `${detection.size}px`,
                        height: `${detection.size}px`,
                      }}
                    >
                      <div className="text-xs bg-neon-green text-black px-2 py-1 rounded font-bold">
                        {detection.type} {Math.round(detection.confidence * 100)}%
                      </div>
                    </div>
                  ))}

                  {/* Center Label */}
                  <div className="relative z-10 text-center">
                    <p className="text-neon-green font-bold text-lg">YOLO DETECTION ACTIVE</p>
                    <p className="text-gray-400 text-sm mt-2">
                      {detections.length} objects detected
                    </p>
                  </div>
                </div>

                {/* Detection Stats Bar */}
                <div className="p-4 border-t border-[rgba(34,197,94,0.2)] grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-neon-green font-bold text-lg">{detections.length}</p>
                    <p className="text-xs text-gray-400">Objects</p>
                  </div>
                  <div className="text-center">
                    <p className="text-neon-green font-bold text-lg">
                      {Math.round(detections.reduce((a, b) => a + b.confidence, 0) / detections.length * 100)}%
                    </p>
                    <p className="text-xs text-gray-400">Avg Confidence</p>
                  </div>
                  <div className="text-center">
                    <p className="text-neon-green font-bold text-lg">45</p>
                    <p className="text-xs text-gray-400">FPS</p>
                  </div>
                </div>
              </GlassCard>
            </div>

            {/* Detection Settings */}
            <div className="space-y-4">
              <GlassCard className="p-6">
                <h2 className="text-lg font-bold text-neon-green mb-4">⚙️ MODEL CONFIG</h2>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Detection Model</label>
                    <select
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2 text-sm"
                    >
                      <option value="yolo-v8">YOLOv8 (Recommended)</option>
                      <option value="yolo-v7">YOLOv7</option>
                      <option value="faster-rcnn">Faster R-CNN</option>
                      <option value="ssd">SSD MobileNet</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Confidence Threshold</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      defaultValue="75"
                      className="w-full"
                    />
                    <p className="text-xs text-neon-green mt-1">75%</p>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Detection Classes</label>
                    <div className="space-y-2 text-sm">
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="w-4 h-4" />
                        <span className="text-gray-300">Person</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="w-4 h-4" />
                        <span className="text-gray-300">Vehicle</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" defaultChecked className="w-4 h-4" />
                        <span className="text-gray-300">Drone</span>
                      </label>
                      <label className="flex items-center gap-2">
                        <input type="checkbox" className="w-4 h-4" />
                        <span className="text-gray-300">Weapon</span>
                      </label>
                    </div>
                  </div>

                  <button className="w-full btn-neon py-2 text-sm mt-4">Start Detection</button>
                </div>
              </GlassCard>

              {/* Real-time Stats */}
              <GlassCard className="p-6">
                <h2 className="text-lg font-bold text-neon-green mb-4">📊 STATS</h2>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">GPU Usage</span>
                    <span className="text-neon-green">67%</span>
                  </div>
                  <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-1">
                    <div className="bg-neon-green h-1 rounded-full" style={{ width: '67%' }} />
                  </div>

                  <div className="flex justify-between mt-3">
                    <span className="text-gray-400">Memory</span>
                    <span className="text-neon-green">2.4 GB</span>
                  </div>
                  <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-1">
                    <div className="bg-neon-green h-1 rounded-full" style={{ width: '48%' }} />
                  </div>

                  <div className="flex justify-between mt-3">
                    <span className="text-gray-400">Latency</span>
                    <span className="text-neon-green">22ms</span>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Anomaly Detection */}
          <div className="animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">🔍 ANOMALY DETECTION</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {anomalies.map((anomaly) => (
                  <div
                    key={anomaly.id}
                    className={`p-4 rounded-lg border-l-4 ${
                      anomaly.severity === 'critical'
                        ? 'border-red-500 bg-red-500/10'
                        : 'border-yellow-500 bg-yellow-500/10'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-bold text-white">{anomaly.type}</h3>
                      <span
                        className={`text-xs font-bold ${
                          anomaly.severity === 'critical' ? 'text-red-500' : 'text-yellow-500'
                        }`}
                      >
                        {anomaly.severity.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">Zone: {anomaly.zone}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">Confidence</span>
                      <span className="text-neon-green font-bold">
                        {Math.round(anomaly.confidence * 100)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>

          {/* Risk Prediction */}
          <div className="animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">⚠️ RISK ZONE PREDICTION</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {['Zone Alpha', 'Zone Beta', 'Zone Gamma', 'Zone Delta'].map((zone, i) => {
                  const risk = [15, 42, 28, 65][i];
                  const riskColor = risk > 50 ? 'text-red-500' : risk > 30 ? 'text-yellow-500' : 'text-neon-green';
                  return (
                    <div key={zone} className="p-4 glass-card rounded-lg">
                      <p className="text-sm text-gray-400 mb-2">{zone}</p>
                      <p className={`text-3xl font-bold ${riskColor}`}>{risk}%</p>
                      <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2 mt-2">
                        <div
                          className={`h-2 rounded-full ${
                            risk > 50 ? 'bg-red-500' : risk > 30 ? 'bg-yellow-500' : 'bg-neon-green'
                          }`}
                          style={{ width: `${risk}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {risk > 50 ? 'HIGH RISK' : risk > 30 ? 'MEDIUM RISK' : 'LOW RISK'}
                      </p>
                    </div>
                  );
                })}
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  );
}
