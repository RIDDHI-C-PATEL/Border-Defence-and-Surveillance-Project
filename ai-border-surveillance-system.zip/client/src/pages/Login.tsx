import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { LoadingAnimation } from '@/components/LoadingAnimation';
import { getLoginUrl } from '@/const';

export default function Login() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = () => {
    setIsLoading(true);
    window.location.href = getLoginUrl();
  };

  return (
    <div className="min-h-screen bg-military-dark flex items-center justify-center p-4">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-neon-green/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Login Container */}
      <div className="relative z-10 w-full max-w-md">
        <div className="glass-panel space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-neon-green to-blue-500 rounded-lg flex items-center justify-center text-3xl">
                🛡️
              </div>
            </div>
            <h1 className="text-3xl font-bold text-neon-green animate-neon-flicker">
              BORDER DEFENSE
            </h1>
            <p className="text-gray-400 text-sm">AI-Powered Surveillance System</p>
            <div className="h-1 w-16 bg-gradient-to-r from-neon-green to-blue-500 mx-auto rounded-full" />
          </div>

          {/* Status Indicators */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 bg-neon-green rounded-full animate-bounce-pulse" />
              <span className="text-gray-300">System Status: <span className="text-neon-green font-bold">OPERATIONAL</span></span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 bg-neon-green rounded-full animate-bounce-pulse" style={{ animationDelay: '0.2s' }} />
              <span className="text-gray-300">Database: <span className="text-neon-green font-bold">CONNECTED</span></span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 bg-neon-green rounded-full animate-bounce-pulse" style={{ animationDelay: '0.4s' }} />
              <span className="text-gray-300">AI Modules: <span className="text-neon-green font-bold">READY</span></span>
            </div>
          </div>

          {/* Login Form */}
          <div className="space-y-4">
            <div className="p-4 bg-[rgba(34,197,94,0.1)] border border-neon-green rounded-lg">
              <p className="text-sm text-gray-300 text-center">
                Secure authentication via Manus OAuth
              </p>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-8">
                <LoadingAnimation size={50} text="Authenticating..." />
              </div>
            ) : (
              <button
                onClick={handleLogin}
                className="w-full btn-neon py-3 text-base font-bold"
              >
                Login to System
              </button>
            )}
          </div>

          {/* Features */}
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="glass-card p-2">
              <div className="text-lg mb-1">🎯</div>
              <p className="text-gray-400">Real-time Detection</p>
            </div>
            <div className="glass-card p-2">
              <div className="text-lg mb-1">🗺️</div>
              <p className="text-gray-400">Live Mapping</p>
            </div>
            <div className="glass-card p-2">
              <div className="text-lg mb-1">📊</div>
              <p className="text-gray-400">Analytics</p>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-xs text-gray-500 space-y-1">
            <p>© 2026 Border Defence System. All rights reserved.</p>
            <p>Classified - For Authorized Personnel Only</p>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="mt-8 grid grid-cols-2 gap-4 text-xs text-gray-500">
          <div className="glass-card p-3 text-center">
            <p className="text-neon-green font-bold">127</p>
            <p>Active Zones</p>
          </div>
          <div className="glass-card p-3 text-center">
            <p className="text-neon-green font-bold">2.3K</p>
            <p>Cameras Online</p>
          </div>
        </div>
      </div>
    </div>
  );
}
