import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, StatCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';
import { MapView } from '@/components/Map';

export default function BorderMap() {
  const { user, logout } = useAuth();
  const [selectedZone, setSelectedZone] = useState(0);
  const [showThreats, setShowThreats] = useState(true);
  const [showDrones, setShowDrones] = useState(true);

  const zones = [
    { id: 0, name: 'Zone Alpha', lat: 35.6762, lng: 139.6503, threats: 3, drones: 2 },
    { id: 1, name: 'Zone Beta', lat: 34.0522, lng: -118.2437, threats: 1, drones: 1 },
    { id: 2, name: 'Zone Gamma', lat: 40.7128, lng: -74.0060, threats: 0, drones: 0 },
  ];

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">BORDER MAP</h1>
            <p className="text-gray-400">Interactive map with threat overlays and patrol routes</p>
          </div>

          {/* Map Controls */}
          <div className="flex flex-wrap gap-2 animate-slide-in-left">
            <label className="flex items-center gap-2 glass-card px-4 py-2 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={showThreats}
                onChange={(e) => setShowThreats(e.target.checked)}
                className="w-4 h-4"
              />
              <span className="text-sm text-gray-300">Show Threats</span>
            </label>
            <label className="flex items-center gap-2 glass-card px-4 py-2 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={showDrones}
                onChange={(e) => setShowDrones(e.target.checked)}
                className="w-4 h-4"
              />
              <span className="text-sm text-gray-300">Show Drones</span>
            </label>
            <button className="btn-neon text-sm py-2 px-3">🔍 Search Location</button>
            <button className="btn-neon text-sm py-2 px-3">📍 Current Location</button>
            <button className="btn-neon text-sm py-2 px-3">📥 Export Map</button>
          </div>

          {/* Main Map */}
          <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
            <GlassCard className="p-0 overflow-hidden">
              <div className="relative bg-black aspect-video rounded-lg overflow-hidden">
                {/* Placeholder Map */}
                <MapView
                  onMapReady={(map) => {
                    console.log('Map ready:', map);
                  }}
                />
              </div>

              {/* Map Legend */}
              <div className="p-4 border-t border-[rgba(34,197,94,0.2)] grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full" />
                  <span className="text-xs text-gray-300">Threat Zone</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-neon-green rounded-full" />
                  <span className="text-xs text-gray-300">Secure Zone</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded-full" />
                  <span className="text-xs text-gray-300">Drone</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-neon-green" />
                  <span className="text-xs text-gray-300">Patrol Route</span>
                </div>
              </div>
            </GlassCard>
          </div>

          {/* Zone Details and Patrol Routes */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            {/* Zone List */}
            <div className="space-y-3">
              <GlassCard className="p-6">
                <h2 className="text-lg font-bold text-neon-green mb-4">📍 BORDER ZONES</h2>
                <div className="space-y-2">
                  {zones.map((zone) => (
                    <div
                      key={zone.id}
                      onClick={() => setSelectedZone(zone.id)}
                      className={`p-3 rounded-lg cursor-pointer transition-all ${
                        selectedZone === zone.id
                          ? 'glass-card-hover border-neon-green bg-[rgba(34,197,94,0.2)]'
                          : 'glass-card hover:border-neon-green'
                      }`}
                    >
                      <p className="font-bold text-white text-sm">{zone.name}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        Threats: <span className="text-red-500">{zone.threats}</span> | Drones:{' '}
                        <span className="text-yellow-500">{zone.drones}</span>
                      </p>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>

            {/* Threat Markers */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">🚨 ACTIVE THREATS</h2>
              <div className="space-y-3">
                {[
                  { id: 1, type: 'Perimeter Breach', zone: 'Zone Alpha', severity: 'critical' },
                  { id: 2, type: 'Unauthorized Vehicle', zone: 'Zone Beta', severity: 'warning' },
                  { id: 3, type: 'Drone Activity', zone: 'Zone Alpha', severity: 'warning' },
                ].map((threat) => (
                  <div
                    key={threat.id}
                    className={`p-3 rounded-lg border-l-4 ${
                      threat.severity === 'critical'
                        ? 'border-red-500 bg-red-500/10'
                        : 'border-yellow-500 bg-yellow-500/10'
                    }`}
                  >
                    <p className="text-sm font-bold text-white">{threat.type}</p>
                    <p className="text-xs text-gray-400 mt-1">{threat.zone}</p>
                    <span
                      className={`text-xs font-bold ${
                        threat.severity === 'critical' ? 'text-red-500' : 'text-yellow-500'
                      }`}
                    >
                      {threat.severity.toUpperCase()}
                    </span>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* Patrol Routes */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">🛣️ PATROL ROUTES</h2>
              <div className="space-y-3">
                {[
                  { id: 1, name: 'Route Alpha-01', status: 'Active', progress: 65 },
                  { id: 2, name: 'Route Beta-02', status: 'Completed', progress: 100 },
                  { id: 3, name: 'Route Gamma-03', status: 'Pending', progress: 0 },
                ].map((route) => (
                  <div key={route.id} className="p-3 glass-card rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-bold text-white">{route.name}</p>
                      <span
                        className={`text-xs font-bold ${
                          route.status === 'Active'
                            ? 'text-neon-green'
                            : route.status === 'Completed'
                              ? 'text-blue-500'
                              : 'text-gray-500'
                        }`}
                      >
                        {route.status}
                      </span>
                    </div>
                    <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                      <div
                        className="bg-neon-green h-2 rounded-full"
                        style={{ width: `${route.progress}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{route.progress}% complete</p>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>

          {/* Map Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
            <StatCard
              label="Total Zones"
              value={zones.length}
              icon="📍"
              trend="stable"
            />
            <StatCard
              label="Active Threats"
              value={zones.reduce((a, b) => a + b.threats, 0)}
              icon="🚨"
              trend="up"
            />
            <StatCard
              label="Drones Deployed"
              value={zones.reduce((a, b) => a + b.drones, 0)}
              icon="🚁"
              trend="stable"
            />
            <StatCard
              label="Coverage"
              value="98.7"
              unit="%"
              icon="📡"
              trend="stable"
            />
          </div>
        </div>
      </main>
    </div>
  );
}
