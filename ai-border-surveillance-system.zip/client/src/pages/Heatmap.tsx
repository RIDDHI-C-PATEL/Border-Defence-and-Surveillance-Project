import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, StatCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Heatmap() {
  const { user, logout } = useAuth();
  const [timeRange, setTimeRange] = useState('24h');

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">THREAT HEATMAP</h1>
            <p className="text-gray-400">Real-time threat density visualization across border zones</p>
          </div>

          {/* Time Range Selection */}
          <div className="flex gap-2 animate-slide-in-left">
            {['1h', '6h', '24h', '7d', '30d'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-lg transition-all ${
                  timeRange === range
                    ? 'btn-neon'
                    : 'glass-card hover:border-neon-green'
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          {/* Main Heatmap */}
          <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
            <GlassCard className="p-0 overflow-hidden">
              <div className="relative bg-black aspect-video flex items-center justify-center">
                {/* Heatmap Visualization */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 600">
                  {/* Background */}
                  <defs>
                    <radialGradient id="heatGradient1" cx="30%" cy="40%">
                      <stop offset="0%" stopColor="rgba(239, 68, 68, 0.8)" />
                      <stop offset="50%" stopColor="rgba(234, 179, 8, 0.4)" />
                      <stop offset="100%" stopColor="rgba(34, 197, 94, 0.1)" />
                    </radialGradient>
                    <radialGradient id="heatGradient2" cx="70%" cy="60%">
                      <stop offset="0%" stopColor="rgba(234, 179, 8, 0.6)" />
                      <stop offset="50%" stopColor="rgba(34, 197, 94, 0.3)" />
                      <stop offset="100%" stopColor="rgba(34, 197, 94, 0.05)" />
                    </radialGradient>
                    <radialGradient id="heatGradient3" cx="50%" cy="80%">
                      <stop offset="0%" stopColor="rgba(34, 197, 94, 0.5)" />
                      <stop offset="100%" stopColor="rgba(34, 197, 94, 0.05)" />
                    </radialGradient>
                  </defs>

                  {/* Grid */}
                  <g stroke="rgba(34, 197, 94, 0.1)" strokeWidth="1">
                    {Array.from({ length: 9 }).map((_, i) => (
                      <line key={`v${i}`} x1={i * 100} y1="0" x2={i * 100} y2="600" />
                    ))}
                    {Array.from({ length: 7 }).map((_, i) => (
                      <line key={`h${i}`} x1="0" y1={i * 100} x2="800" y2={i * 100} />
                    ))}
                  </g>

                  {/* Heat Circles */}
                  <circle cx="240" cy="240" r="150" fill="url(#heatGradient1)" />
                  <circle cx="560" cy="360" r="120" fill="url(#heatGradient2)" />
                  <circle cx="400" cy="480" r="100" fill="url(#heatGradient3)" />

                  {/* Zone Labels */}
                  <text x="240" y="240" textAnchor="middle" fill="#22c55e" fontSize="14" fontWeight="bold">
                    ZONE ALPHA
                  </text>
                  <text x="560" y="360" textAnchor="middle" fill="#22c55e" fontSize="14" fontWeight="bold">
                    ZONE BETA
                  </text>
                  <text x="400" y="480" textAnchor="middle" fill="#22c55e" fontSize="14" fontWeight="bold">
                    ZONE GAMMA
                  </text>
                </svg>

                {/* Legend */}
                <div className="absolute bottom-4 left-4 z-10 glass-card p-3 text-xs">
                  <p className="text-neon-green font-bold mb-2">Threat Level</p>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full" />
                      <span className="text-gray-300">Critical</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                      <span className="text-gray-300">High</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-neon-green rounded-full" />
                      <span className="text-gray-300">Low</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div className="p-4 border-t border-[rgba(34,197,94,0.2)] flex gap-2">
                <button className="btn-neon text-sm py-1 px-3">🔍 Zoom In</button>
                <button className="btn-neon text-sm py-1 px-3">🔍 Zoom Out</button>
                <button className="btn-neon text-sm py-1 px-3">📊 Export</button>
                <button className="btn-neon text-sm py-1 px-3">🔄 Refresh</button>
              </div>
            </GlassCard>
          </div>

          {/* Zone Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            <StatCard
              label="Highest Threat Zone"
              value="Zone Alpha"
              icon="🔴"
              trend="up"
            />
            <StatCard
              label="Average Threat Level"
              value="42"
              unit="%"
              icon="📊"
              trend="stable"
            />
            <StatCard
              label="Incidents (24h)"
              value="12"
              unit="events"
              icon="⚠️"
              trend="down"
            />
          </div>

          {/* Detailed Zone Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
            {/* Zone Details */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📍 ZONE ANALYSIS</h2>
              <div className="space-y-4">
                {[
                  { name: 'Zone Alpha', threat: 78, incidents: 5, status: 'Critical' },
                  { name: 'Zone Beta', threat: 45, incidents: 2, status: 'Medium' },
                  { name: 'Zone Gamma', threat: 32, incidents: 1, status: 'Low' },
                  { name: 'Zone Delta', threat: 15, incidents: 0, status: 'Secure' },
                ].map((zone) => (
                  <div key={zone.name} className="p-3 bg-[rgba(34,197,94,0.1)] rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-bold text-white">{zone.name}</h3>
                      <span
                        className={`text-xs font-bold ${
                          zone.threat > 60
                            ? 'text-red-500'
                            : zone.threat > 30
                              ? 'text-yellow-500'
                              : 'text-neon-green'
                        }`}
                      >
                        {zone.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-gray-400">Threat Level</span>
                      <span className="text-neon-green font-bold">{zone.threat}%</span>
                    </div>
                    <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          zone.threat > 60
                            ? 'bg-red-500'
                            : zone.threat > 30
                              ? 'bg-yellow-500'
                              : 'bg-neon-green'
                        }`}
                        style={{ width: `${zone.threat}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      {zone.incidents} incident{zone.incidents !== 1 ? 's' : ''} in last 24h
                    </p>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* Activity Timeline */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📈 ACTIVITY TIMELINE</h2>
              <div className="space-y-3">
                {[
                  { time: '14:32', event: 'Perimeter Breach - Zone Alpha', severity: 'critical' },
                  { time: '13:15', event: 'Drone Activity Detected - Zone Beta', severity: 'warning' },
                  { time: '12:48', event: 'Vehicle Crossing - Zone Gamma', severity: 'warning' },
                  { time: '11:22', event: 'System Check Passed', severity: 'info' },
                  { time: '10:05', event: 'Threat Level Update', severity: 'info' },
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3 pb-3 border-b border-[rgba(34,197,94,0.1)] last:border-0">
                    <span className="text-neon-green font-bold text-sm whitespace-nowrap">{item.time}</span>
                    <div className="flex-1">
                      <p className="text-sm text-gray-300">{item.event}</p>
                      <span
                        className={`text-xs font-bold ${
                          item.severity === 'critical'
                            ? 'text-red-500'
                            : item.severity === 'warning'
                              ? 'text-yellow-500'
                              : 'text-blue-500'
                        }`}
                      >
                        {item.severity.toUpperCase()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  );
}
