import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, StatCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function Reports() {
  const { user, logout } = useAuth();
  const [reportType, setReportType] = useState('daily');

  // Mock data for charts
  const activityData = [
    { time: '00:00', threats: 2, detections: 5, incidents: 1 },
    { time: '04:00', threats: 1, detections: 3, incidents: 0 },
    { time: '08:00', threats: 5, detections: 12, incidents: 2 },
    { time: '12:00', threats: 8, detections: 18, incidents: 3 },
    { time: '16:00', threats: 6, detections: 15, incidents: 2 },
    { time: '20:00', threats: 9, detections: 22, incidents: 4 },
    { time: '23:59', threats: 3, detections: 8, incidents: 1 },
  ];

  const detectionStats = [
    { name: 'Person', value: 145 },
    { name: 'Vehicle', value: 87 },
    { name: 'Drone', value: 23 },
    { name: 'Other', value: 12 },
  ];

  const zoneRiskData = [
    { zone: 'Zone Alpha', risk: 78, incidents: 5 },
    { zone: 'Zone Beta', risk: 45, incidents: 2 },
    { zone: 'Zone Gamma', risk: 32, incidents: 1 },
    { zone: 'Zone Delta', risk: 15, incidents: 0 },
  ];

  const COLORS = ['#22c55e', '#0ea5e9', '#06b6d4', '#8b5cf6'];

  const handleLogout = async () => {
    await logout();
  };

  const handleExport = (format: 'pdf' | 'csv' | 'json') => {
    alert(`Exporting report as ${format.toUpperCase()}...`);
  };

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">REPORTS & ANALYTICS</h1>
            <p className="text-gray-400">Comprehensive surveillance data analysis and reporting</p>
          </div>

          {/* Report Type Selection */}
          <div className="flex flex-wrap gap-2 animate-slide-in-left">
            {['daily', 'weekly', 'monthly', 'custom'].map((type) => (
              <button
                key={type}
                onClick={() => setReportType(type)}
                className={`px-4 py-2 rounded-lg transition-all capitalize ${
                  reportType === type
                    ? 'btn-neon'
                    : 'glass-card hover:border-neon-green'
                }`}
              >
                {type} Report
              </button>
            ))}
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
            <StatCard
              label="Total Detections"
              value="267"
              unit="today"
              icon="🎯"
              trend="up"
            />
            <StatCard
              label="Threat Events"
              value="12"
              unit="active"
              icon="🚨"
              trend="up"
            />
            <StatCard
              label="Detection Accuracy"
              value="94.7"
              unit="%"
              icon="📊"
              trend="stable"
            />
            <StatCard
              label="System Uptime"
              value="99.8"
              unit="%"
              icon="💚"
              trend="stable"
            />
          </div>

          {/* Activity Timeline Chart */}
          <div className="animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📈 ACTIVITY TIMELINE (24H)</h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={activityData}>
                  <CartesianGrid stroke="rgba(34, 197, 94, 0.1)" />
                  <XAxis stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: '1px solid rgba(34, 197, 94, 0.3)',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="threats"
                    stroke="#ef4444"
                    strokeWidth={2}
                    dot={{ fill: '#ef4444', r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="detections"
                    stroke="#22c55e"
                    strokeWidth={2}
                    dot={{ fill: '#22c55e', r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="incidents"
                    stroke="#eab308"
                    strokeWidth={2}
                    dot={{ fill: '#eab308', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </GlassCard>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
            {/* Detection Types */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">🎯 DETECTION BREAKDOWN</h2>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={detectionStats}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#22c55e"
                    dataKey="value"
                  >
                    {detectionStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: '1px solid rgba(34, 197, 94, 0.3)',
                      borderRadius: '8px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </GlassCard>

            {/* Zone Risk Analysis */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📍 ZONE RISK ANALYSIS</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={zoneRiskData}>
                  <CartesianGrid stroke="rgba(34, 197, 94, 0.1)" />
                  <XAxis stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      border: '1px solid rgba(34, 197, 94, 0.3)',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="risk" fill="#22c55e" name="Risk Level %" />
                  <Bar dataKey="incidents" fill="#ef4444" name="Incidents" />
                </BarChart>
              </ResponsiveContainer>
            </GlassCard>
          </div>

          {/* Summary Statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-slide-in-left" style={{ animationDelay: '0.3s' }}>
            {/* Detection Summary */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">🎯 DETECTION SUMMARY</h2>
              <div className="space-y-3">
                {detectionStats.map((stat) => (
                  <div key={stat.name} className="flex items-center justify-between">
                    <span className="text-gray-300">{stat.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-neon-green font-bold">{stat.value}</span>
                      <span className="text-xs text-gray-500">
                        {Math.round((stat.value / detectionStats.reduce((a, b) => a + b.value, 0)) * 100)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* Incident Summary */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">⚠️ INCIDENT SUMMARY</h2>
              <div className="space-y-3">
                {[
                  { label: 'Critical', value: 3, color: 'text-red-500' },
                  { label: 'High', value: 5, color: 'text-yellow-500' },
                  { label: 'Medium', value: 2, color: 'text-blue-500' },
                  { label: 'Low', value: 2, color: 'text-neon-green' },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between">
                    <span className="text-gray-300">{item.label}</span>
                    <span className={`font-bold ${item.color}`}>{item.value}</span>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* Export Options */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📥 EXPORT REPORT</h2>
              <div className="space-y-2">
                <button
                  onClick={() => handleExport('pdf')}
                  className="w-full btn-neon py-2 text-sm"
                >
                  📄 Export as PDF
                </button>
                <button
                  onClick={() => handleExport('csv')}
                  className="w-full btn-neon py-2 text-sm"
                >
                  📊 Export as CSV
                </button>
                <button
                  onClick={() => handleExport('json')}
                  className="w-full btn-neon py-2 text-sm"
                >
                  📋 Export as JSON
                </button>
                <button className="w-full btn-neon py-2 text-sm">
                  📧 Email Report
                </button>
              </div>
            </GlassCard>
          </div>

          {/* Detailed Insights */}
          <div className="animate-slide-in-right" style={{ animationDelay: '0.3s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">💡 KEY INSIGHTS</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  {
                    title: 'Peak Activity Time',
                    value: '20:00 - 22:00',
                    description: 'Highest threat activity detected during evening hours',
                  },
                  {
                    title: 'Most Active Zone',
                    value: 'Zone Alpha',
                    description: '78% risk level with 5 incidents in last 24 hours',
                  },
                  {
                    title: 'Detection Accuracy',
                    value: '94.7%',
                    description: 'AI model achieving excellent accuracy on object detection',
                  },
                  {
                    title: 'Response Time',
                    value: '2.3 seconds',
                    description: 'Average time from detection to alert notification',
                  },
                ].map((insight, i) => (
                  <div key={i} className="p-4 bg-[rgba(34,197,94,0.1)] rounded-lg border border-neon-green">
                    <p className="text-sm text-gray-400 mb-1">{insight.title}</p>
                    <p className="text-lg font-bold text-neon-green mb-2">{insight.value}</p>
                    <p className="text-xs text-gray-500">{insight.description}</p>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  );
}
