import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Settings() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('system');
  const [settings, setSettings] = useState({
    systemName: 'Border Defence System',
    timezone: 'UTC',
    language: 'English',
    theme: 'dark',
    autoBackup: true,
    backupInterval: 'daily',
    emailNotifications: true,
    smsNotifications: false,
    criticalAlertsOnly: false,
    alertEmail: user?.email || 'operator@border-defense.gov',
    alertPhone: '+1-555-0123',
  });

  const handleLogout = async () => {
    await logout();
  };

  const handleSettingChange = (key: string, value: any) => {
    setSettings({ ...settings, [key]: value });
  };

  const handleSaveSettings = () => {
    alert('Settings saved successfully!');
  };

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">SYSTEM SETTINGS</h1>
            <p className="text-gray-400">Configure system preferences, notifications, and border zones</p>
          </div>

          {/* Tab Navigation */}
          <div className="flex flex-wrap gap-2 animate-slide-in-left">
            {[
              { id: 'system', label: 'System Config', icon: '⚙️' },
              { id: 'notifications', label: 'Notifications', icon: '🔔' },
              { id: 'zones', label: 'Border Zones', icon: '📍' },
              { id: 'users', label: 'User Management', icon: '👥' },
              { id: 'security', label: 'Security', icon: '🔐' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-lg transition-all flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'btn-neon'
                    : 'glass-card hover:border-neon-green'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* System Configuration */}
          {activeTab === 'system' && (
            <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="p-6 space-y-6">
                <h2 className="text-lg font-bold text-neon-green">⚙️ SYSTEM CONFIGURATION</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm text-gray-400 block mb-2">System Name</label>
                    <input
                      type="text"
                      value={settings.systemName}
                      onChange={(e) => handleSettingChange('systemName', e.target.value)}
                      className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                    />
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Timezone</label>
                    <select
                      value={settings.timezone}
                      onChange={(e) => handleSettingChange('timezone', e.target.value)}
                      className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                    >
                      <option>UTC</option>
                      <option>EST</option>
                      <option>CST</option>
                      <option>MST</option>
                      <option>PST</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Language</label>
                    <select
                      value={settings.language}
                      onChange={(e) => handleSettingChange('language', e.target.value)}
                      className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                    >
                      <option>English</option>
                      <option>Spanish</option>
                      <option>French</option>
                      <option>German</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Theme</label>
                    <select
                      value={settings.theme}
                      onChange={(e) => handleSettingChange('theme', e.target.value)}
                      className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                    >
                      <option>Dark</option>
                      <option>Light</option>
                      <option>Auto</option>
                    </select>
                  </div>
                </div>

                <div className="border-t border-[rgba(34,197,94,0.2)] pt-6">
                  <h3 className="text-md font-bold text-neon-green mb-4">Backup Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={settings.autoBackup}
                        onChange={(e) => handleSettingChange('autoBackup', e.target.checked)}
                        className="w-4 h-4"
                      />
                      <span className="text-gray-300">Enable Automatic Backups</span>
                    </label>

                    <div>
                      <label className="text-sm text-gray-400 block mb-2">Backup Interval</label>
                      <select
                        value={settings.backupInterval}
                        onChange={(e) => handleSettingChange('backupInterval', e.target.value)}
                        className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                      >
                        <option>Hourly</option>
                        <option>Daily</option>
                        <option>Weekly</option>
                        <option>Monthly</option>
                      </select>
                    </div>
                  </div>
                </div>

                <button onClick={handleSaveSettings} className="w-full btn-neon py-2 mt-4">
                  💾 Save Settings
                </button>
              </GlassCard>
            </div>
          )}

          {/* Notifications */}
          {activeTab === 'notifications' && (
            <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="p-6 space-y-6">
                <h2 className="text-lg font-bold text-neon-green">🔔 NOTIFICATION SETTINGS</h2>

                <div className="space-y-4">
                  <label className="flex items-center gap-3 p-4 glass-card rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.emailNotifications}
                      onChange={(e) => handleSettingChange('emailNotifications', e.target.checked)}
                      className="w-4 h-4"
                    />
                    <div className="flex-1">
                      <p className="text-gray-300 font-semibold">Email Notifications</p>
                      <p className="text-xs text-gray-500">Receive alerts via email</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-4 glass-card rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.smsNotifications}
                      onChange={(e) => handleSettingChange('smsNotifications', e.target.checked)}
                      className="w-4 h-4"
                    />
                    <div className="flex-1">
                      <p className="text-gray-300 font-semibold">SMS Notifications</p>
                      <p className="text-xs text-gray-500">Receive critical alerts via SMS</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-4 glass-card rounded-lg cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.criticalAlertsOnly}
                      onChange={(e) => handleSettingChange('criticalAlertsOnly', e.target.checked)}
                      className="w-4 h-4"
                    />
                    <div className="flex-1">
                      <p className="text-gray-300 font-semibold">Critical Alerts Only</p>
                      <p className="text-xs text-gray-500">Only notify for critical severity incidents</p>
                    </div>
                  </label>
                </div>

                <div className="border-t border-[rgba(34,197,94,0.2)] pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-400 block mb-2">Alert Email Address</label>
                      <input
                        type="email"
                        value={settings.alertEmail}
                        onChange={(e) => handleSettingChange('alertEmail', e.target.value)}
                        className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                      />
                    </div>

                    <div>
                      <label className="text-sm text-gray-400 block mb-2">Alert Phone Number</label>
                      <input
                        type="tel"
                        value={settings.alertPhone}
                        onChange={(e) => handleSettingChange('alertPhone', e.target.value)}
                        className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                      />
                    </div>
                  </div>
                </div>

                <button onClick={handleSaveSettings} className="w-full btn-neon py-2 mt-4">
                  💾 Save Settings
                </button>
              </GlassCard>
            </div>
          )}

          {/* Border Zones */}
          {activeTab === 'zones' && (
            <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="p-6 space-y-6">
                <h2 className="text-lg font-bold text-neon-green">📍 BORDER ZONES MANAGEMENT</h2>

                <div className="space-y-3">
                  {[
                    { name: 'Zone Alpha', country: 'Country A', cameras: 12, status: 'active' },
                    { name: 'Zone Beta', country: 'Country B', cameras: 8, status: 'active' },
                    { name: 'Zone Gamma', country: 'Country C', cameras: 15, status: 'active' },
                    { name: 'Zone Delta', country: 'Country D', cameras: 6, status: 'inactive' },
                  ].map((zone) => (
                    <div key={zone.name} className="p-4 glass-card rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="font-bold text-white">{zone.name}</p>
                          <p className="text-xs text-gray-500">{zone.country}</p>
                        </div>
                        <span
                          className={`text-xs font-bold px-2 py-1 rounded ${
                            zone.status === 'active'
                              ? 'bg-neon-green/20 text-neon-green'
                              : 'bg-gray-500/20 text-gray-500'
                          }`}
                        >
                          {zone.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-3">Cameras: {zone.cameras}</p>
                      <div className="flex gap-2">
                        <button className="btn-neon text-xs py-1 px-2">✏️ Edit</button>
                        <button className="btn-neon text-xs py-1 px-2">🗑️ Delete</button>
                      </div>
                    </div>
                  ))}
                </div>

                <button className="w-full btn-neon py-2">➕ Add New Zone</button>
              </GlassCard>
            </div>
          )}

          {/* User Management */}
          {activeTab === 'users' && (
            <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="p-6 space-y-6">
                <h2 className="text-lg font-bold text-neon-green">👥 USER MANAGEMENT</h2>

                <div className="space-y-3">
                  {[
                    { name: 'Admin User', email: 'admin@border-defense.gov', role: 'Admin', status: 'active' },
                    { name: 'Operator 1', email: 'operator1@border-defense.gov', role: 'Operator', status: 'active' },
                    { name: 'Operator 2', email: 'operator2@border-defense.gov', role: 'Operator', status: 'active' },
                    { name: 'Analyst', email: 'analyst@border-defense.gov', role: 'Analyst', status: 'inactive' },
                  ].map((u) => (
                    <div key={u.email} className="p-4 glass-card rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="font-bold text-white">{u.name}</p>
                          <p className="text-xs text-gray-500">{u.email}</p>
                        </div>
                        <span
                          className={`text-xs font-bold px-2 py-1 rounded ${
                            u.status === 'active'
                              ? 'bg-neon-green/20 text-neon-green'
                              : 'bg-gray-500/20 text-gray-500'
                          }`}
                        >
                          {u.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-3">Role: {u.role}</p>
                      <div className="flex gap-2">
                        <button className="btn-neon text-xs py-1 px-2">✏️ Edit</button>
                        <button className="btn-neon text-xs py-1 px-2">🔑 Reset Password</button>
                      </div>
                    </div>
                  ))}
                </div>

                <button className="w-full btn-neon py-2">➕ Add New User</button>
              </GlassCard>
            </div>
          )}

          {/* Security */}
          {activeTab === 'security' && (
            <div className="animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="p-6 space-y-6">
                <h2 className="text-lg font-bold text-neon-green">🔐 SECURITY SETTINGS</h2>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Session Timeout (minutes)</label>
                    <input
                      type="number"
                      defaultValue="30"
                      className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2"
                    />
                  </div>

                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Password Policy</label>
                    <select className="w-full bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-2">
                      <option>Standard (8+ characters)</option>
                      <option>Strong (12+ characters, mixed case)</option>
                      <option>Maximum (16+ characters, special chars)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="flex items-center gap-3">
                      <input type="checkbox" defaultChecked className="w-4 h-4" />
                      <span className="text-gray-300">Enable Two-Factor Authentication</span>
                    </label>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" defaultChecked className="w-4 h-4" />
                      <span className="text-gray-300">Enable IP Whitelist</span>
                    </label>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" defaultChecked className="w-4 h-4" />
                      <span className="text-gray-300">Enable Audit Logging</span>
                    </label>
                  </div>

                  <div className="border-t border-[rgba(34,197,94,0.2)] pt-4">
                    <p className="text-sm text-gray-400 mb-3">Last Security Audit: 2 days ago</p>
                    <button className="btn-neon py-2 px-4">🔍 Run Security Audit</button>
                  </div>
                </div>

                <button onClick={handleSaveSettings} className="w-full btn-neon py-2 mt-4">
                  💾 Save Settings
                </button>
              </GlassCard>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
