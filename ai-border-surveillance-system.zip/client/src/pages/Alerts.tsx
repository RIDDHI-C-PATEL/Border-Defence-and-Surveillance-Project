import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, AlertCard, StatCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Alerts() {
  const { user, logout } = useAuth();
  const [severityFilter, setSeverityFilter] = useState<'all' | 'critical' | 'warning' | 'info'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'acknowledged' | 'resolved'>('all');
  const [dismissedAlerts, setDismissedAlerts] = useState<number[]>([]);

  const allAlerts = [
    {
      id: 1,
      title: 'CRITICAL: Perimeter Breach',
      message: 'Unauthorized entry detected at Zone Alpha northern gate. Immediate response required.',
      severity: 'critical' as const,
      status: 'active' as const,
      timestamp: new Date(),
      zone: 'Zone Alpha',
    },
    {
      id: 2,
      title: 'Drone Activity Detected',
      message: 'Unidentified aerial object spotted near Zone Beta. Analyzing trajectory.',
      severity: 'warning' as const,
      status: 'active' as const,
      timestamp: new Date(Date.now() - 5 * 60000),
      zone: 'Zone Beta',
    },
    {
      id: 3,
      title: 'Vehicle Crossing Alert',
      message: 'Unauthorized vehicle detected crossing Zone Gamma boundary.',
      severity: 'warning' as const,
      status: 'acknowledged' as const,
      timestamp: new Date(Date.now() - 15 * 60000),
      zone: 'Zone Gamma',
    },
    {
      id: 4,
      title: 'System Health Check',
      message: 'All surveillance cameras online and operational. System status: OPTIMAL',
      severity: 'info' as const,
      status: 'resolved' as const,
      timestamp: new Date(Date.now() - 30 * 60000),
      zone: 'System',
    },
    {
      id: 5,
      title: 'Anomaly Detected',
      message: 'Unusual movement pattern detected in Zone Delta. Confidence: 87%',
      severity: 'warning' as const,
      status: 'active' as const,
      timestamp: new Date(Date.now() - 45 * 60000),
      zone: 'Zone Delta',
    },
    {
      id: 6,
      title: 'Database Backup Complete',
      message: 'Daily database backup completed successfully.',
      severity: 'info' as const,
      status: 'resolved' as const,
      timestamp: new Date(Date.now() - 60 * 60000),
      zone: 'System',
    },
  ];

  const filteredAlerts = allAlerts.filter((alert) => {
    const severityMatch = severityFilter === 'all' || alert.severity === severityFilter;
    const statusMatch = statusFilter === 'all' || alert.status === statusFilter;
    const notDismissed = !dismissedAlerts.includes(alert.id);
    return severityMatch && statusMatch && notDismissed;
  });

  const handleLogout = async () => {
    await logout();
  };

  const handleDismiss = (id: number) => {
    setDismissedAlerts([...dismissedAlerts, id]);
  };

  const criticalCount = allAlerts.filter((a) => a.severity === 'critical' && !dismissedAlerts.includes(a.id)).length;
  const activeCount = allAlerts.filter((a) => a.status === 'active' && !dismissedAlerts.includes(a.id)).length;

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">ALERT MANAGEMENT</h1>
            <p className="text-gray-400">Real-time alert monitoring with severity filtering and history</p>
          </div>

          {/* Alert Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-slide-in-left">
            <StatCard
              label="Critical Alerts"
              value={criticalCount}
              icon="🔴"
              trend="up"
            />
            <StatCard
              label="Active Alerts"
              value={activeCount}
              icon="⚠️"
              trend="stable"
            />
            <StatCard
              label="Acknowledged"
              value={allAlerts.filter((a) => a.status === 'acknowledged').length}
              icon="✓"
              trend="down"
            />
            <StatCard
              label="Resolved (24h)"
              value={allAlerts.filter((a) => a.status === 'resolved').length}
              icon="✓✓"
              trend="stable"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-3 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
            <div className="glass-card p-3 rounded-lg">
              <label className="text-sm text-gray-400 block mb-2">Severity</label>
              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value as any)}
                className="bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-1 text-sm"
              >
                <option value="all">All Severities</option>
                <option value="critical">Critical Only</option>
                <option value="warning">Warnings Only</option>
                <option value="info">Info Only</option>
              </select>
            </div>

            <div className="glass-card p-3 rounded-lg">
              <label className="text-sm text-gray-400 block mb-2">Status</label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="bg-[rgba(34,197,94,0.1)] border border-neon-green text-neon-green rounded px-3 py-1 text-sm"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="acknowledged">Acknowledged Only</option>
                <option value="resolved">Resolved Only</option>
              </select>
            </div>

            <button className="btn-neon text-sm py-2 px-3">🔔 Enable Notifications</button>
            <button className="btn-neon text-sm py-2 px-3">📧 Email Settings</button>
            <button className="btn-neon text-sm py-2 px-3">📱 SMS Settings</button>
          </div>

          {/* Active Alerts */}
          <div className="animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">
                🚨 LIVE ALERTS ({filteredAlerts.length})
              </h2>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredAlerts.length > 0 ? (
                  filteredAlerts.map((alert) => (
                    <AlertCard
                      key={alert.id}
                      title={alert.title}
                      message={alert.message}
                      severity={alert.severity}
                      timestamp={alert.timestamp}
                      onDismiss={() => handleDismiss(alert.id)}
                    />
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400">No alerts matching your filters</p>
                  </div>
                )}
              </div>
            </GlassCard>
          </div>

          {/* Alert Details Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-slide-in-right" style={{ animationDelay: '0.2s' }}>
            {/* Alert by Zone */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📍 ALERTS BY ZONE</h2>
              <div className="space-y-3">
                {['Zone Alpha', 'Zone Beta', 'Zone Gamma', 'Zone Delta', 'System'].map((zone) => {
                  const zoneAlerts = allAlerts.filter(
                    (a) => a.zone === zone && !dismissedAlerts.includes(a.id)
                  );
                  return (
                    <div key={zone} className="flex items-center justify-between p-3 glass-card rounded-lg">
                      <span className="text-gray-300">{zone}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-neon-green font-bold">{zoneAlerts.length}</span>
                        <span className="text-xs text-gray-500">alert{zoneAlerts.length !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </GlassCard>

            {/* Alert Severity Distribution */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📊 SEVERITY DISTRIBUTION</h2>
              <div className="space-y-4">
                {[
                  { label: 'Critical', count: allAlerts.filter((a) => a.severity === 'critical' && !dismissedAlerts.includes(a.id)).length, color: 'bg-red-500' },
                  { label: 'Warning', count: allAlerts.filter((a) => a.severity === 'warning' && !dismissedAlerts.includes(a.id)).length, color: 'bg-yellow-500' },
                  { label: 'Info', count: allAlerts.filter((a) => a.severity === 'info' && !dismissedAlerts.includes(a.id)).length, color: 'bg-blue-500' },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-300">{item.label}</span>
                      <span className="text-neon-green font-bold">{item.count}</span>
                    </div>
                    <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${item.color}`}
                        style={{ width: `${(item.count / allAlerts.length) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>

          {/* Alert History */}
          <div className="animate-slide-in-left" style={{ animationDelay: '0.3s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">📜 ALERT HISTORY</h2>
              <div className="space-y-2 text-sm">
                {allAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-center justify-between p-3 glass-card rounded-lg opacity-75"
                  >
                    <div className="flex-1">
                      <p className="text-gray-300">{alert.title}</p>
                      <p className="text-xs text-gray-500">{alert.timestamp.toLocaleTimeString()}</p>
                    </div>
                    <span
                      className={`text-xs font-bold px-2 py-1 rounded ${
                        alert.severity === 'critical'
                          ? 'bg-red-500/20 text-red-500'
                          : alert.severity === 'warning'
                            ? 'bg-yellow-500/20 text-yellow-500'
                            : 'bg-blue-500/20 text-blue-500'
                      }`}
                    >
                      {alert.severity.toUpperCase()}
                    </span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  );
}
