import React, { useEffect, useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, StatCard, AlertCard } from '@/components/GlassCard';
import { RadarAnimation } from '@/components/RadarAnimation';
import { LoadingAnimation } from '@/components/LoadingAnimation';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [alerts, setAlerts] = useState<any[]>([]);

  // Fetch dashboard stats
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();

  useEffect(() => {
    // Simulate fetching alerts
    const mockAlerts = [
      {
        id: 1,
        title: 'Unauthorized Entry Detected',
        message: 'Zone Alpha - Potential breach at northern perimeter',
        severity: 'critical' as const,
        timestamp: new Date(),
      },
      {
        id: 2,
        title: 'Drone Activity',
        message: 'Zone Beta - Unidentified aerial object detected',
        severity: 'warning' as const,
        timestamp: new Date(Date.now() - 5 * 60000),
      },
      {
        id: 3,
        title: 'System Check',
        message: 'All surveillance cameras online and operational',
        severity: 'info' as const,
        timestamp: new Date(Date.now() - 10 * 60000),
      },
    ];
    setAlerts(mockAlerts);
  }, []);

  const handleLogout = async () => {
    await logout();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-military-dark flex items-center justify-center">
        <LoadingAnimation size={80} text="Initializing System..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      {/* Main Content */}
      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">COMMAND CENTER</h1>
            <p className="text-gray-400">Real-time Border Surveillance & Threat Analysis</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-slide-in-left">
            <StatCard
              label="Active Zones"
              value={stats?.activeZones || 0}
              unit="/ 127"
              icon="🎯"
              trend="stable"
            />
            <StatCard
              label="Critical Alerts"
              value={stats?.criticalAlerts || 0}
              unit="active"
              icon="🚨"
              trend="up"
            />
            <StatCard
              label="Recent Threats"
              value={stats?.recentThreats || 0}
              unit="detected"
              icon="⚠️"
              trend="down"
            />
            <StatCard
              label="System Health"
              value="98.7"
              unit="%"
              icon="💚"
              trend="stable"
            />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Radar Section */}
            <div className="lg:col-span-1 animate-slide-in-left" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="flex flex-col items-center justify-center p-8">
                <h2 className="text-lg font-bold text-neon-green mb-4">RADAR SCAN</h2>
                <RadarAnimation size={200} pulseCount={3} />
                <p className="text-xs text-gray-500 mt-4 text-center">
                  Real-time threat detection & tracking
                </p>
              </GlassCard>
            </div>

            {/* Alerts Section */}
            <div className="lg:col-span-2 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
              <GlassCard className="h-full">
                <h2 className="text-lg font-bold text-neon-green mb-4">LIVE ALERTS</h2>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {alerts.map((alert) => (
                    <AlertCard
                      key={alert.id}
                      title={alert.title}
                      message={alert.message}
                      severity={alert.severity}
                      timestamp={alert.timestamp}
                      onDismiss={() => setAlerts(alerts.filter((a) => a.id !== alert.id))}
                    />
                  ))}
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Activity Timeline */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            {/* Drone Monitoring */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">🚁 DRONE MONITORING</h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-[rgba(34,197,94,0.1)] rounded-lg">
                  <div>
                    <p className="font-bold text-white">Drone Alpha-01</p>
                    <p className="text-xs text-gray-400">Zone A - Patrol Route</p>
                  </div>
                  <span className="text-neon-green font-bold">● ACTIVE</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-[rgba(34,197,94,0.1)] rounded-lg">
                  <div>
                    <p className="font-bold text-white">Drone Beta-02</p>
                    <p className="text-xs text-gray-400">Zone B - Charging</p>
                  </div>
                  <span className="text-yellow-500 font-bold">● IDLE</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-[rgba(34,197,94,0.1)] rounded-lg">
                  <div>
                    <p className="font-bold text-white">Drone Gamma-03</p>
                    <p className="text-xs text-gray-400">Zone C - Maintenance</p>
                  </div>
                  <span className="text-red-500 font-bold">● OFFLINE</span>
                </div>
              </div>
            </GlassCard>

            {/* System Status */}
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">⚙️ SYSTEM STATUS</h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">AI Detection Engine</span>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-neon-green rounded-full animate-bounce-pulse" />
                    <span className="text-neon-green text-sm font-bold">RUNNING</span>
                  </div>
                </div>
                <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                  <div className="bg-neon-green h-2 rounded-full" style={{ width: '87%' }} />
                </div>

                <div className="flex items-center justify-between mt-4">
                  <span className="text-gray-300">Database Connection</span>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-neon-green rounded-full animate-bounce-pulse" />
                    <span className="text-neon-green text-sm font-bold">CONNECTED</span>
                  </div>
                </div>
                <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                  <div className="bg-neon-green h-2 rounded-full" style={{ width: '100%' }} />
                </div>

                <div className="flex items-center justify-between mt-4">
                  <span className="text-gray-300">API Response Time</span>
                  <span className="text-neon-green text-sm font-bold">42ms</span>
                </div>
                <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                  <div className="bg-neon-green h-2 rounded-full" style={{ width: '94%' }} />
                </div>
              </div>
            </GlassCard>
          </div>

          {/* Footer */}
          <div className="text-center text-xs text-gray-500 py-4">
            <p>Last updated: {new Date().toLocaleTimeString()}</p>
          </div>
        </div>
      </main>
    </div>
  );
}
