import React, { useState } from 'react';
import { SidebarNav } from '@/components/SidebarNav';
import { GlassCard, StatCard } from '@/components/GlassCard';
import { useAuth } from '@/_core/hooks/useAuth';

export default function Surveillance() {
  const { user, logout } = useAuth();
  const [selectedZone, setSelectedZone] = useState(0);

  const zones = [
    { id: 0, name: 'Zone Alpha', status: 'online', cameras: 12, threats: 0 },
    { id: 1, name: 'Zone Beta', status: 'online', cameras: 8, threats: 1 },
    { id: 2, name: 'Zone Gamma', status: 'online', cameras: 15, threats: 0 },
    { id: 3, name: 'Zone Delta', status: 'offline', cameras: 6, threats: 2 },
  ];

  const selectedZoneData = zones[selectedZone];

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="min-h-screen bg-military-dark">
      <SidebarNav onLogout={handleLogout} userName={user?.name || 'Operator'} />

      <main className="md:ml-64 p-4 md:p-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-neon-green mb-2">SURVEILLANCE MONITORING</h1>
            <p className="text-gray-400">Multi-border live feed management & drone control</p>
          </div>

          {/* Zone Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-slide-in-left">
            {zones.map((zone) => (
              <div
                key={zone.id}
                onClick={() => setSelectedZone(zone.id)}
                className={`glass-card-hover p-4 cursor-pointer transition-all ${
                  selectedZone === zone.id
                    ? 'border-neon-green bg-[rgba(34,197,94,0.2)]'
                    : 'border-[rgba(34,197,94,0.2)]'
                }`}
              >
                <h3 className="font-bold text-white mb-2">{zone.name}</h3>
                <div className="space-y-1 text-sm">
                  <p className="text-gray-400">
                    Status:{' '}
                    <span
                      className={zone.status === 'online' ? 'text-neon-green' : 'text-red-500'}
                    >
                      {zone.status.toUpperCase()}
                    </span>
                  </p>
                  <p className="text-gray-400">Cameras: <span className="text-neon-green">{zone.cameras}</span></p>
                  <p className="text-gray-400">
                    Threats: <span className={zone.threats > 0 ? 'text-red-500' : 'text-neon-green'}>{zone.threats}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Live Feed Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-slide-in-right" style={{ animationDelay: '0.1s' }}>
            {/* Main Feed */}
            <div className="lg:col-span-2">
              <GlassCard className="p-0 overflow-hidden">
                <div className="relative bg-black aspect-video flex items-center justify-center">
                  {/* Simulated Video Feed */}
                  <div className="absolute inset-0 bg-gradient-to-br from-green-900/20 to-black/50" />
                  <div className="relative z-10 text-center">
                    <div className="text-6xl mb-4">📹</div>
                    <p className="text-neon-green font-bold text-lg">LIVE FEED - {selectedZoneData.name}</p>
                    <p className="text-gray-400 text-sm mt-2">
                      {selectedZoneData.status === 'online' ? 'Streaming...' : 'Offline'}
                    </p>
                  </div>
                  {selectedZoneData.status === 'online' && (
                    <div className="absolute top-4 right-4 flex items-center gap-2 bg-red-500/20 px-3 py-1 rounded-lg">
                      <span className="w-2 h-2 bg-red-500 rounded-full animate-bounce" />
                      <span className="text-red-500 text-xs font-bold">RECORDING</span>
                    </div>
                  )}
                </div>

                {/* Feed Controls */}
                <div className="p-4 border-t border-[rgba(34,197,94,0.2)] flex gap-2">
                  <button className="btn-neon text-sm py-1 px-3">📷 Capture</button>
                  <button className="btn-neon text-sm py-1 px-3">🔍 Zoom</button>
                  <button className="btn-neon text-sm py-1 px-3">🔄 Rotate</button>
                  <button className="btn-neon text-sm py-1 px-3">📊 Analytics</button>
                </div>
              </GlassCard>
            </div>

            {/* Drone Control Panel */}
            <div className="space-y-4">
              <GlassCard className="p-6">
                <h2 className="text-lg font-bold text-neon-green mb-4">🚁 DRONE CONTROL</h2>
                <div className="space-y-3">
                  <div className="p-3 bg-[rgba(34,197,94,0.1)] rounded-lg">
                    <p className="text-xs text-gray-400 mb-1">Active Drone</p>
                    <p className="font-bold text-white">Drone-Alpha-01</p>
                    <p className="text-xs text-neon-green mt-1">● OPERATIONAL</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button className="btn-neon text-xs py-2">↑ Forward</button>
                    <button className="btn-neon text-xs py-2">↓ Backward</button>
                    <button className="btn-neon text-xs py-2">← Left</button>
                    <button className="btn-neon text-xs py-2">→ Right</button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button className="btn-neon text-xs py-2">⬆️ Up</button>
                    <button className="btn-neon text-xs py-2">⬇️ Down</button>
                  </div>

                  <div className="p-3 bg-[rgba(34,197,94,0.1)] rounded-lg">
                    <p className="text-xs text-gray-400 mb-2">Battery</p>
                    <div className="w-full bg-[rgba(34,197,94,0.1)] rounded-full h-2">
                      <div className="bg-neon-green h-2 rounded-full" style={{ width: '78%' }} />
                    </div>
                    <p className="text-xs text-neon-green mt-1">78% - Good</p>
                  </div>
                </div>
              </GlassCard>

              {/* Multi-Zone Overview */}
              <GlassCard className="p-6">
                <h2 className="text-lg font-bold text-neon-green mb-4">ZONE STATUS</h2>
                <div className="space-y-2">
                  {zones.map((zone) => (
                    <div key={zone.id} className="flex items-center justify-between text-sm">
                      <span className="text-gray-300">{zone.name}</span>
                      <span
                        className={zone.status === 'online' ? 'text-neon-green' : 'text-red-500'}
                      >
                        ● {zone.status === 'online' ? 'Online' : 'Offline'}
                      </span>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Camera Grid */}
          <div className="animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
            <GlassCard className="p-6">
              <h2 className="text-lg font-bold text-neon-green mb-4">
                📹 CAMERA FEEDS - {selectedZoneData.name}
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array.from({ length: selectedZoneData.cameras }).map((_, i) => (
                  <div key={i} className="aspect-video bg-black rounded-lg flex items-center justify-center border border-[rgba(34,197,94,0.2)] hover:border-neon-green transition-all cursor-pointer">
                    <div className="text-center">
                      <p className="text-neon-green text-sm font-bold">CAM-{String(i + 1).padStart(2, '0')}</p>
                      <p className="text-xs text-gray-500 mt-1">● ONLINE</p>
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      </main>
    </div>
  );
}
