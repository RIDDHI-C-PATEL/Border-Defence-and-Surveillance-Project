import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { LiveClock } from './LiveClock';

interface NavItem {
  label: string;
  path: string;
  icon: string;
}

const navItems: NavItem[] = [
  { label: 'Dashboard', path: '/dashboard', icon: '📊' },
  { label: 'Surveillance', path: '/surveillance', icon: '📹' },
  { label: 'AI Detection', path: '/detection', icon: '🤖' },
  { label: 'Heatmap', path: '/heatmap', icon: '🔥' },
  { label: 'Border Map', path: '/map', icon: '🗺️' },
  { label: 'Alerts', path: '/alerts', icon: '⚠️' },
  { label: 'Reports', path: '/reports', icon: '📈' },
  { label: 'Settings', path: '/settings', icon: '⚙️' },
];

interface SidebarNavProps {
  onLogout?: () => void;
  userName?: string;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({ onLogout, userName = 'Operator' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  const toggleSidebar = () => setIsOpen(!isOpen);

  return (
    <>
      {/* Mobile Toggle Button */}
      <button
        onClick={toggleSidebar}
        className="fixed top-4 left-4 z-50 md:hidden glass-card p-2 rounded-lg hover:bg-[rgba(34,197,94,0.2)]"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar Overlay (Mobile) */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed left-0 top-0 h-screen w-64 glass-card border-r border-[rgba(34,197,94,0.2)] flex flex-col z-40 transition-transform duration-300 md:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Header */}
        <div className="p-6 border-b border-[rgba(34,197,94,0.2)]">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 bg-neon-green rounded-lg flex items-center justify-center text-military-dark font-bold">
              🛡️
            </div>
            <h1 className="text-lg font-bold text-neon-green animate-neon-flicker">BORDER DEFENSE</h1>
          </div>
          <p className="text-xs text-gray-500">AI Surveillance System</p>
        </div>

        {/* Live Clock */}
        <div className="px-6 py-4 border-b border-[rgba(34,197,94,0.2)]">
          <LiveClock format="24h" showDate showDay />
        </div>

        {/* User Info */}
        <div className="px-6 py-4 border-b border-[rgba(34,197,94,0.2)]">
          <p className="text-sm text-gray-300">Logged in as</p>
          <p className="font-bold text-neon-green text-sm">{userName}</p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            {navItems.map((item) => {
              const isActive = location === item.path;
              return (
                <Link key={item.path} href={item.path}>
                  <a
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 text-sm',
                      isActive
                        ? 'glass-card-hover bg-[rgba(34,197,94,0.2)] border-l-2 border-neon-green text-neon-green'
                        : 'text-gray-300 hover:text-neon-green hover:bg-[rgba(34,197,94,0.1)]'
                    )}
                    onClick={() => setIsOpen(false)}
                  >
                    <span className="text-lg">{item.icon}</span>
                    <span className="font-semibold">{item.label}</span>
                    {isActive && <span className="ml-auto text-neon-green">●</span>}
                  </a>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-[rgba(34,197,94,0.2)] space-y-2">
          <button
            onClick={onLogout}
            className="w-full btn-neon text-sm py-2"
          >
            Logout
          </button>
          <div className="text-xs text-gray-500 text-center">
            <p>System Status: <span className="text-neon-green">● ONLINE</span></p>
          </div>
        </div>
      </aside>

      {/* Main Content Offset */}
      <div className="md:ml-64" />
    </>
  );
};

export default SidebarNav;
