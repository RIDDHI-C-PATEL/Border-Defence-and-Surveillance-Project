import React from 'react';

interface RadarAnimationProps {
  size?: number;
  pulseCount?: number;
  className?: string;
}

export const RadarAnimation: React.FC<RadarAnimationProps> = ({
  size = 200,
  pulseCount = 3,
  className = '',
}) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="animate-radar-sweep"
      >
        {/* Background circles */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={size / 6}
          fill="none"
          stroke="rgba(34, 197, 94, 0.2)"
          strokeWidth="1"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={(size / 3)}
          fill="none"
          stroke="rgba(34, 197, 94, 0.2)"
          strokeWidth="1"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={(size / 2) - 10}
          fill="none"
          stroke="rgba(34, 197, 94, 0.3)"
          strokeWidth="2"
        />

        {/* Crosshair */}
        <line
          x1={size / 2}
          y1="10"
          x2={size / 2}
          y2={size - 10}
          stroke="rgba(34, 197, 94, 0.2)"
          strokeWidth="1"
        />
        <line
          x1="10"
          y1={size / 2}
          x2={size - 10}
          y2={size / 2}
          stroke="rgba(34, 197, 94, 0.2)"
          strokeWidth="1"
        />

        {/* Radar sweep line */}
        <line
          x1={size / 2}
          y1={size / 2}
          x2={size / 2}
          y2="20"
          stroke="#22c55e"
          strokeWidth="2"
          opacity="0.8"
        />

        {/* Pulsing circles */}
        {Array.from({ length: pulseCount }).map((_, i) => (
          <circle
            key={i}
            cx={size / 2}
            cy={size / 2}
            r={10 + i * 20}
            fill="none"
            stroke="#22c55e"
            strokeWidth="1"
            opacity={0.6 - i * 0.15}
            className="animate-radar-pulse"
            style={{ animationDelay: `${i * 0.4}s` }}
          />
        ))}

        {/* Center dot */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r="4"
          fill="#22c55e"
          className="animate-bounce-pulse"
        />
      </svg>
    </div>
  );
};

export default RadarAnimation;
