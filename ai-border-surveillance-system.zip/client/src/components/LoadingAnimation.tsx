import React from 'react';

interface LoadingAnimationProps {
  size?: number;
  text?: string;
  className?: string;
}

export const LoadingAnimation: React.FC<LoadingAnimationProps> = ({
  size = 60,
  text = 'Loading...',
  className = '',
}) => {
  return (
    <div className={`flex flex-col items-center justify-center gap-4 ${className}`}>
      <div className="relative" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="animate-loading-spin"
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r={size / 2 - 4}
            fill="none"
            stroke="rgba(34, 197, 94, 0.2)"
            strokeWidth="2"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={size / 2 - 4}
            fill="none"
            stroke="#22c55e"
            strokeWidth="2"
            strokeDasharray={`${(size / 2 - 4) * Math.PI * 0.5} ${(size / 2 - 4) * Math.PI * 2}`}
            strokeLinecap="round"
          />
        </svg>
        <div
          className="absolute inset-0 flex items-center justify-center text-neon-green text-xs font-bold"
          style={{ fontSize: size / 6 }}
        >
          {Math.round((Math.random() * 100))}%
        </div>
      </div>
      {text && <p className="text-neon-green text-sm font-bold animate-pulse">{text}</p>}
    </div>
  );
};

export default LoadingAnimation;
