import React from 'react';
import { cn } from '@/lib/utils';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  onClick?: () => void;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className = '',
  hover = false,
  onClick,
}) => {
  return (
    <div
      className={cn(
        'glass-card p-4 rounded-lg',
        hover && 'glass-card-hover cursor-pointer',
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon?: React.ReactNode;
  trend?: 'up' | 'down' | 'stable';
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  unit,
  icon,
  trend,
  className = '',
}) => {
  const trendColor =
    trend === 'up' ? 'text-red-500' : trend === 'down' ? 'text-green-500' : 'text-yellow-500';

  return (
    <GlassCard className={`flex flex-col gap-2 ${className}`}>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-400">{label}</span>
        {icon && <div className="text-neon-green">{icon}</div>}
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold text-neon-green">{value}</span>
        {unit && <span className="text-sm text-gray-500">{unit}</span>}
      </div>
      {trend && (
        <div className={`text-xs font-semibold ${trendColor}`}>
          {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'} {Math.abs(Math.random() * 10).toFixed(1)}%
        </div>
      )}
    </GlassCard>
  );
};

interface AlertCardProps {
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  timestamp?: Date;
  onDismiss?: () => void;
  className?: string;
}

export const AlertCard: React.FC<AlertCardProps> = ({
  title,
  message,
  severity,
  timestamp,
  onDismiss,
  className = '',
}) => {
  const severityColor =
    severity === 'critical'
      ? 'border-red-500 bg-red-500/10'
      : severity === 'warning'
        ? 'border-yellow-500 bg-yellow-500/10'
        : 'border-blue-500 bg-blue-500/10';

  const severityLabel =
    severity === 'critical' ? '🔴 CRITICAL' : severity === 'warning' ? '🟡 WARNING' : '🔵 INFO';

  return (
    <GlassCard className={`border-l-4 ${severityColor} ${className}`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-bold ${severity === 'critical' ? 'text-red-500' : severity === 'warning' ? 'text-yellow-500' : 'text-blue-500'}`}>
              {severityLabel}
            </span>
            <h3 className="font-bold text-white">{title}</h3>
          </div>
          <p className="text-sm text-gray-300 mt-1">{message}</p>
          {timestamp && (
            <p className="text-xs text-gray-500 mt-2">
              {new Date(timestamp).toLocaleTimeString()}
            </p>
          )}
        </div>
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="text-gray-500 hover:text-neon-green transition-colors ml-2"
          >
            ✕
          </button>
        )}
      </div>
    </GlassCard>
  );
};

export default GlassCard;
