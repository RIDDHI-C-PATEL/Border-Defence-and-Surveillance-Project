import React, { useState, useEffect } from 'react';

interface LiveClockProps {
  className?: string;
  showDate?: boolean;
  showDay?: boolean;
  format?: '12h' | '24h';
}

/**
 * LiveClock Component
 * Displays real-time system clock with date and day of week
 * Updates every second for accurate time display
 */
export function LiveClock({
  className = '',
  showDate = true,
  showDay = true,
  format = '24h',
}: LiveClockProps) {
  const [time, setTime] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [day, setDay] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();

      // Format time
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');

      if (format === '24h') {
        setTime(`${hours}:${minutes}:${seconds}`);
      } else {
        const hour12 = now.getHours() % 12 || 12;
        const ampm = now.getHours() >= 12 ? 'PM' : 'AM';
        setTime(`${String(hour12).padStart(2, '0')}:${minutes}:${seconds} ${ampm}`);
      }

      // Format date
      const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
      ];
      const dateStr = `${monthNames[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
      setDate(dateStr);

      // Format day
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      setDay(dayNames[now.getDay()]);
    };

    // Update immediately
    updateClock();

    // Update every second
    const interval = setInterval(updateClock, 1000);

    return () => clearInterval(interval);
  }, [format]);

  return (
    <div className={`text-neon-green font-mono ${className}`}>
      <div className="text-2xl font-bold tracking-wider animate-neon-flicker">
        {time}
      </div>
      {(showDate || showDay) && (
        <div className="text-xs text-gray-400 mt-1 space-y-0.5">
          {showDay && <div>{day}</div>}
          {showDate && <div>{date}</div>}
        </div>
      )}
    </div>
  );
}

export default LiveClock;
